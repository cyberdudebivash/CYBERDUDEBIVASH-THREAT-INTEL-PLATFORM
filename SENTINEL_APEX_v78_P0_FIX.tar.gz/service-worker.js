// ═══════════════════════════════════════════════════════
// CYBERDUDEBIVASH SENTINEL APEX — Service Worker v78.0
// v78.0 FIX: Removed skipWaiting + clients.claim + controllerchange reload
// which caused the P0 "BOOTING..." loop on every 6-hour pipeline deploy.
//
// Strategy: Stable background update — activates on next natural page load.
// Dashboard renders instantly from EMBEDDED_INTEL — SW is for asset caching only.
// ═══════════════════════════════════════════════════════

const CACHE_VERSION = 'sentinel-apex-v78';
const CACHE_NAME    = CACHE_VERSION;

// Assets to cache for offline use (non-HTML, non-data only)
const STATIC_ASSETS = [
    '/manifest.json',
    '/assets/sentinel-apex-thumbnail.jpg',
];

// ── Install: cache static assets, wait for explicit activation ──
// v78.0: Removed self.skipWaiting() — new SW waits for old pages to close
//        before taking control, preventing the reload loop
self.addEventListener('install', event => {
    console.log('[SW v78] Installing:', CACHE_VERSION);
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
            return cache.addAll(STATIC_ASSETS).catch(err => {
                console.warn('[SW v78] Pre-cache failed (non-fatal):', err);
            });
        })
    );
    // Do NOT call self.skipWaiting() — avoids the reload loop
});

// ── Activate: clear old caches, do NOT claim clients aggressively ──
// v78.0: Removed self.clients.claim() — prevents triggering controllerchange
//        on currently open pages (which caused the reload loop)
self.addEventListener('activate', event => {
    console.log('[SW v78] Activating:', CACHE_VERSION);
    event.waitUntil(
        caches.keys().then(keys => {
            return Promise.all(
                keys
                    .filter(key => key !== CACHE_NAME)
                    .map(key => {
                        console.log('[SW v78] Deleting old cache:', key);
                        return caches.delete(key);
                    })
            );
        })
        // Do NOT call self.clients.claim() here — avoids controllerchange reload
    );
});

// ── Message handler: allow manual skip-waiting if needed ──
self.addEventListener('message', event => {
    if (event.data && event.data.type === 'SKIP_WAITING') {
        console.log('[SW v78] Manual SKIP_WAITING received');
        self.skipWaiting();
    }
});

// ── Fetch: network-first for HTML/data, stale-while-revalidate for assets ──
self.addEventListener('fetch', event => {
    const url = new URL(event.request.url);

    // NEVER cache: index.html, data files, API endpoints — always network-first
    if (
        url.pathname === '/'                        ||
        url.pathname === '/index.html'              ||
        url.pathname.includes('feed_manifest')      ||
        url.pathname.includes('sync_marker')        ||
        url.pathname.includes('status.json')        ||
        url.pathname.includes('api/')               ||
        url.hostname === 'raw.githubusercontent.com'||
        url.hostname === 'cdn.jsdelivr.net'
    ) {
        event.respondWith(
            fetch(event.request, { cache: 'no-store' }).catch(() => {
                // Offline fallback: serve cached version if available
                return caches.match(event.request);
            })
        );
        return;
    }

    // For static assets: cache-first with network fallback
    event.respondWith(
        caches.match(event.request).then(cached => {
            if (cached) return cached;
            return fetch(event.request).then(response => {
                if (response && response.status === 200 && response.type === 'basic') {
                    const clone = response.clone();
                    caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
                }
                return response;
            }).catch(() => {
                // Asset fetch failed — return nothing gracefully
                return new Response('', { status: 503, statusText: 'Offline' });
            });
        })
    );
});

# CYBERDUDEBIVASH SENTINEL APEX Sigma Rules

Generated: 2026-11-01T19:17:07.409844+00:00
Version: 162.0.0

Use sigma-cli to convert to your target SIEM format:
```
sigma convert -t splunk apex/*.yml
sigma convert -t microsoft365defender apex/*.yml
```

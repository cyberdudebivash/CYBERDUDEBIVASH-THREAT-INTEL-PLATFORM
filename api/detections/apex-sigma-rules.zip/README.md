# CYBERDUDEBIVASH SENTINEL APEX Sigma Rules

Generated: 2026-11-09T10:31:44.920340+00:00
Version: 162.0.0

Use sigma-cli to convert to your target SIEM format:
```
sigma convert -t splunk apex/*.yml
sigma convert -t microsoft365defender apex/*.yml
```

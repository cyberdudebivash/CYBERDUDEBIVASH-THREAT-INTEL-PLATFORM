# CYBERDUDEBIVASH SENTINEL APEX Sigma Rules

Generated: 2026-11-10T10:34:57.580701+00:00
Version: 162.0.0

Use sigma-cli to convert to your target SIEM format:
```
sigma convert -t splunk apex/*.yml
sigma convert -t microsoft365defender apex/*.yml
```
